package com.bi.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.bi.beans.Car;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("com/bi/common/application-context.xml"));
		Car car1=(Car)factory.getBean("car1");
		System.out.println(car1);
		Car car2=(Car)factory.getBean("car2");
		System.out.println(car2);
		Car car3=(Car)factory.getBean("car4");
		System.out.println(car3);
	}

}
