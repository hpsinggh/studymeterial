package com.bi.beans;

public class Car {
				private String brand_name;
				private String fuel_type;
				private String color;
				private int price;
				public void setBrand_name(String brand_name) {
					this.brand_name = brand_name;
				}
				public void setColor(String color) {
					this.color = color;
				}
				public void setFuel_type(String fuel_type) {
					this.fuel_type = fuel_type;
				}
				public void setPrice(int price) {
					this.price = price;
				}
				@Override
				public String toString() {
					return "Car [brand_name=" + brand_name + ", fuel_type=" + fuel_type + ", color=" + color
							+ ", price=" + price + "]";
				}
}
