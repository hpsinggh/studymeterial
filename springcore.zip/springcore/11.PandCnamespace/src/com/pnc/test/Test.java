package com.pnc.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.pnc.beans.Mobile1;


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/pnc/common/application-context.xml"));
		       	Mobile1 mobile1=(Mobile1)factory.getBean("mobile1");
		        System.out.println(mobile1);
	}

}
