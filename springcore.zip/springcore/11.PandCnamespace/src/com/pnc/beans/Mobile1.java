package com.pnc.beans;

public class Mobile1 {
		private String mobile_menufacturer;
		private String model;
		private Sim sim;
		public void setMobile_menufacturer(String mobile_menufacturer) {
			this.mobile_menufacturer = mobile_menufacturer;
		}
		public void setModel(String model) {
			this.model = model;
		}
		public void setSim(Sim sim) {
			this.sim = sim;
		}
		@Override
		public String toString() {
			return "Mobile1 [mobile_menufacturer=" + mobile_menufacturer + ", model=" + model + ", sim=" + sim + "]";
		}
		
}
