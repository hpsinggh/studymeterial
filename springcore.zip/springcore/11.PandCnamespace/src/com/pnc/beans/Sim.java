package com.pnc.beans;

public class Sim {
		private int simno;
		private String storage_capacity;
		
		public Sim(int simno, String storage_capacity) {
			super();
			this.simno = simno;
			this.storage_capacity = storage_capacity;
		}

		@Override
		public String toString() {
			return "Sim [simno=" + simno + ", storage_capacity=" + storage_capacity + "]";
		}
		
}
