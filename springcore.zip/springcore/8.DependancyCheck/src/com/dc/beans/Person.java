package com.dc.beans;

public class Person {
			private Passport passport;
			private String ssn;
			public void setPassport(Passport passport) {
				this.passport = passport;
			}
			public void setSsn(String ssn) {
				this.ssn = ssn;
			}
			@Override
			public String toString() {
				return "Person [passport=" + passport + ", ssn=" + ssn + "]";
			}
}
