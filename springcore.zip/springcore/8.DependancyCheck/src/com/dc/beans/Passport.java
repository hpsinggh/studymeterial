package com.dc.beans;

public class Passport {
	private int passportNo;
	private String first_name;
	private String last_name;
	public Passport() {
		super();
	System.out.println("passport has been created.");
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public void setPassportNo(int passportNo) {
		this.passportNo = passportNo;
	}
	@Override
	public String toString() {
		return "Passport [passportNo=" + passportNo + ", first_name=" + first_name + ", last_name=" + last_name + "]";
	}
	
	

}
