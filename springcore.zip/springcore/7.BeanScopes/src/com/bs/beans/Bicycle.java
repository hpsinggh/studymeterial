package com.bs.beans;

public class Bicycle {
			private String brand_name;
			private int id;
			public void setBrand_name(String brand_name) {
				this.brand_name = brand_name;
			}
			public void setId(int id) {
				this.id = id;
			}
			
}
