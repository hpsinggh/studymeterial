package com.bs.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.bs.beans.Bicycle;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("com/bs/common/application-context.xml"));
		Bicycle bicycle1=factory.getBean("bicycle1",Bicycle.class);
		Bicycle bicycle2=factory.getBean("bicycle1",Bicycle.class);
		System.out.println("hash code of bicycle1"+bicycle1);
		System.out.println("hash code of bicycle2"+bicycle2);
	}

}
