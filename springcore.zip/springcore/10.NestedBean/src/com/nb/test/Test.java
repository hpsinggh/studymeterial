package com.nb.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.nb.beans.Computer;


public class Test {
	public static void main(String[] args) {
	BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/nb/common/application-context.xml"));
   	Computer computer=(Computer)factory.getBean("com.nb.beans.Computer#0");
    System.out.println(computer);
	}
}
