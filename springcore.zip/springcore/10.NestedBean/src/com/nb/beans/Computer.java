package com.nb.beans;

public class Computer {
		private String brand_name;
		private String computer_type;
		private Chip chip;
		public void setBrand_name(String brand_name) {
			this.brand_name = brand_name;
		}
		public void setComputer_type(String computer_type) {
			this.computer_type = computer_type;
		}
		public void setChip(Chip chip) {
			this.chip = chip;
		}
		@Override
		public String toString() {
			return "Computer [brand_name=" + brand_name + ", computer_type=" + computer_type + ", chip=" + chip + "]";
		}
}
