package com.nb.beans;
public class Chip {
			private String chiptype;
			private int chipid;
			public void setChiptype(String chiptype) {
				this.chiptype = chiptype;
			}
			public void setChipid(int chipid) {
				this.chipid = chipid;
			}
			@Override
			public String toString() {
				return "Chip [chiptype=" + chiptype + ", chipid=" + chipid + "]";
			}
}
