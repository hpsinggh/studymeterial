package com.cm.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.cm.beans.Product;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/cm/common/application-context.xml"));
		Product product=factory.getBean("iphone6s",Product.class);
		System.out.println(product);
	}

}
