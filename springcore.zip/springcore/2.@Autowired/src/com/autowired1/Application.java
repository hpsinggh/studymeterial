package com.autowired1;

import org.springframework.beans.factory.annotation.Autowired;
//this example tell me that Autowired annotation can be use at any level.
//if u apply @Autowired on property then no need of setter or constructor or orbiter method to define even, for injection.
//if u apply @Autowired on every component the first constructor injection will executes then all orbitary method, then all setters.
//if u apply @Autowired on multiple constructor then error will come.
//if u apply @Autowired on property only and parameterize constructor is there then error will come bcoz of absance of defalut constructor 
//means directly assignment will be done only after constructor execution.
public class Application {
			//till now as per my best knowldge autowiring is not working for premitivs
			private String applicationname;
			@Autowired
			private ApplicationUser applicationuser;
			
			
            private ApplicationOwner applicationowner;
            @Autowired
			public void setApplicationowner(ApplicationOwner applicationowner) {
				this.applicationowner = applicationowner;
				System.out.println("setter for application owner invoked");
			}
            @Autowired
            public void setApplicationuser(ApplicationUser applicationuser) {
				this.applicationuser = applicationuser;
				System.out.println("setter for application user invoked");
			}
           

			public void setApplicationname(String applicationname) {
				this.applicationname = applicationname;
			}
		
			 @Autowired	
			public Application(ApplicationUser applicationuser) {
				super();
				this.applicationuser = applicationuser;
				System.out.println("constructor for application user invoked");
			}
			 @Autowired
			 public void access(ApplicationOwner applicationowner) {
				 System.out.println("orbitrary method for application owner invoked");
					this.applicationowner = applicationowner;
				}
			 
		/*	public Application(ApplicationOwner applicationowner) {
				super();
				this.applicationowner = applicationowner;
			}*/

			   //orbitrary method
			@Autowired
			public void assign(ApplicationUser applicationuser) {
				this.applicationuser = applicationuser;
				System.out.println("orbitrary method for application user invoked");
			}
			
			@Override
			public String toString() {
				return "Application [applicationname=" + applicationname + ", applicationuser=" + applicationuser
						+ ", applicationowner=" + applicationowner + "]";
			}				
}