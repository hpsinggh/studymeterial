package com.autowired2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
public class Application {
		    
			private String applicationname;
			
			@Autowired
			@Qualifier("user2")
			private ApplicationUser applicationuser;
			
			@Autowired
			@Qualifier("owner2")
            private ApplicationOwner applicationowner;
            
            public void setApplicationuser(ApplicationUser applicationuser) {
				this.applicationuser = applicationuser;
			}
			
			public void setApplicationname(String applicationname) {
				this.applicationname = applicationname;
			}
			
	

			@Override
			public String toString() {
				return "Application [applicationname=" + applicationname + ", applicationuser=" + applicationuser
						+ ", applicationowner=" + applicationowner + "]";
			}				
}