package com.autowired2;

public class ApplicationUser {

			private String username;
			private String password;
			public void setUsername(String username) {
				this.username = username;
			}
			public void setPassword(String password) {
				this.password = password;
			}
			@Override
			public String toString() {
				return "ApplicationUser [username=" + username + ", password=" + password + "]";
			}
}
