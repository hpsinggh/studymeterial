package com.value1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Company {
			@Value("Hcl")
			private String Companyname;
			@Autowired(required=false)
			private Employee employee;
			@Override
			public String toString() {
				return "Company [Companyname=" + Companyname + ", employee=" + employee + "]";
			}
}
