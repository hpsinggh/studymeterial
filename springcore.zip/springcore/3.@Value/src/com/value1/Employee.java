package com.value1;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component ("EMP")    //streoType annotation
public class Employee {
			@Value("Hirendra")
			private String fname;
			@Value("singh")
			private String lname;
			@Value("40000")
			private int salary;
			@Override
			public String toString() {
				return "Employee [fname=" + fname + ", lname=" + lname + ", salary=" + salary + "]";
			}	
}
