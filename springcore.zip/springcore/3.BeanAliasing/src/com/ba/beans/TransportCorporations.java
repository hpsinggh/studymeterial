package com.ba.beans;

public class TransportCorporations {
			private String name;
			private int registration_no;
			public void setName(String name) {
				this.name = name;
			}
			public void setRegistration_no(int registration_no) {
				this.registration_no = registration_no;
			}
			@Override
			public String toString() {
				return "TransportCorporations [name=" + name + ", registration_no=" + registration_no + "]";
			}
}
