package com.cc.beans;

public class Machine {
			private String machine_name;
			private int machine_id;
			public Machine(String machine_name) {
				super();
				this.machine_name = machine_name;
			}
			public Machine(int machine_id) {
				super();
				this.machine_id = machine_id;
			}
			@Override
			public String toString() {
				return "Machine [machine_name=" + machine_name + ", machine_id=" + machine_id + "]";
			}
}
