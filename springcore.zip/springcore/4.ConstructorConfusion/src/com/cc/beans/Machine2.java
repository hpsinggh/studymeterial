package com.cc.beans;

public class Machine2 {
			
		private int machine_id;
		private String machine_name;
		private long machine_sno;
		
		public Machine2(int machine_id, String machine_name, long machine_sno) {
			super();
			this.machine_id = machine_id;
			this.machine_name = machine_name;
			this.machine_sno = machine_sno;
		}
		@Override
		public String toString() {
			return "Machine2 [machine_id=" + machine_id + ", machine_name=" + machine_name + ", machine_sno="
					+ machine_sno + "]";
		}
}
