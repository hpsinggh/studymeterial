package com.cd.beans;

public class Engine {
		
			public void start()
			{
				System.out.println("engine has been started.");
			}
}
//for practice i have implemented here lookup method injection.