package com.cd.beans;

public abstract class Car {
		public void drive()
		{
			Engine engine=null;
			engine=engineLookup();
			engine.start();
			System.out.println("car is driving");
		}
		public abstract Engine engineLookup();
}
