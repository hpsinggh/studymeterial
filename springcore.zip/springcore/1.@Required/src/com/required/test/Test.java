package com.required.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.required.beans.Passport;
import com.required.beans.Person;
public class Test {
	public static void main(String[] args) {
	ApplicationContext context=new FileSystemXmlApplicationContext("src/com/required/common/application-context.xml");
/*	Person person=(Person)context.getBean("person1");
	System.out.println(person);*/
	Passport passport=(Passport)context.getBean("passport");
	System.out.println(passport);
	}
}