package com.required.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;

public class Passport {
			//if dependent bean is not exist then also Passport will create with out person
			//@Autowired(required=false)
	
			//minimum 1 dependent bean must be available for given case.
			@Autowired
			private Person person;
			private String passportno;
			public void setPerson(Person person) {
				this.person = person;
			}
			public void setPassportno(String passportno) {
				this.passportno = passportno;
			}
			@Override
			public String toString() {
				return "Passport [person=" + person + ", passportno=" + passportno + "]";
			}
			//both are same
			
			//@Autowired(required=true)
			//or
			//@Required
			//@Autowired
}
