package com.required.beans;

import org.springframework.beans.factory.annotation.Required;

public class Person {
			private String fname;
			private String lname;
			private int age;
			
			@Required
			public void setFname(String fname) {
				this.fname = fname;
			}

			public void setLname(String lname) {
				this.lname = lname;
			}
			public void setAge(int age) {
				this.age = age;
			}

			@Override
			public String toString() {
				return "Person [fname=" + fname + ", lname=" + lname + ", age=" + age + "]";
			}
}