package com.awbyname.beans;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class TestApp {

	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/awbyname/beans/application-context.xml"));
		Application app=(Application) factory.getBean("application");
		System.out.println(app);
	}
}
