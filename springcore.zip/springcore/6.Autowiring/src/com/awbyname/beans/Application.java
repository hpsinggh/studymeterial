package com.awbyname.beans;

public class Application {
			
			private String applicationname;
			private ApplicationUser applicationuser;

			public void setApplicationuser(ApplicationUser applicationuser) {
				this.applicationuser = applicationuser;
			}
			
			public void setApplicationname(String applicationname) {
				this.applicationname = applicationname;
			}

			@Override
			public String toString() {
				return "Application [applicationname=" + applicationname + ", applicationuser=" + applicationuser + "]";
			}

			
}
