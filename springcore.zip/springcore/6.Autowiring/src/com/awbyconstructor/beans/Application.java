package com.awbyconstructor.beans;

public class Application {

	private ApplicationUser applicationuser;
	private ApplicationOwner applicationowner;

	public Application(ApplicationUser applicationuser) {
		super();
		this.applicationuser = applicationuser;
	}

	public Application(ApplicationOwner applicationowner) {
		super();
		this.applicationowner = applicationowner;
	}

	
	/*public Application(ApplicationUser applicationuser, ApplicationOwner applicationowner) {
		super();
		this.applicationuser = applicationuser;
		this.applicationowner = applicationowner;
	}
*/
	@Override
	public String toString() {
		return "Application [applicationuser=" + applicationuser + ", applicationowner=" + applicationowner + "]";
	}

}
