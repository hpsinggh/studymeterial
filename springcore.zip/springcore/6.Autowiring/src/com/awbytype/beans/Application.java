package com.awbytype.beans;

public class Application {
			
			private ApplicationUser applicationuser;

			public void setApplicationuser(ApplicationUser applicationuser) {
				this.applicationuser = applicationuser;
			}

			@Override
			public String toString() {
				return "Application [applicationuser=" + applicationuser + "]";
			}
			
}
