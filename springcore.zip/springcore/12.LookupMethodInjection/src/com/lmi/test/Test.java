package com.lmi.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.lmi.beans.Car;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			BeanFactory factory=new XmlBeanFactory(new ClassPathResource("com/lmi/common/application-configuration.xml"));
			Car car=factory.getBean("car",Car.class);
			car.drive();
	}

}
