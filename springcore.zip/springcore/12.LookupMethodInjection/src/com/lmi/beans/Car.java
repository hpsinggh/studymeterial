package com.lmi.beans;

public abstract class Car {
		public void drive()
		{
			IEngine iengine=null;
			iengine=lookupEngine();
			iengine.start();
			System.out.println("Car is driven");
		}
		abstract public IEngine lookupEngine();
}
