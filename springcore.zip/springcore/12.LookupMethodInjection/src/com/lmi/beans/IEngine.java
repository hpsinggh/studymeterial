package com.lmi.beans;

public interface IEngine {
		public void start();
}
