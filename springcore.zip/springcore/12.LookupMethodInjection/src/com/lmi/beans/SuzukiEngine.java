package com.lmi.beans;

public class SuzukiEngine implements IEngine{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("Suzuki engine get started");
	}
	

}
