package com.lmi.beans;

public class YamahaEngine implements IEngine{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("yamaha engine get started");
	}

}
