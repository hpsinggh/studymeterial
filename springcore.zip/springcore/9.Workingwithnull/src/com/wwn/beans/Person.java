package com.wwn.beans;

public class Person {
		private int ssn;
		private String name;
		public Person(int ssn) {
			super();
			this.ssn = ssn;
		}
		public Person(String name) {
			super();
			this.name = name;
		}
		@Override
		public String toString() {
			return "Person [ssn=" + ssn + ", name=" + name + "]";
		}
}
