package com.inject;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
//@Resource is as same as @Named and @Autowired,so once you check that one also. 
@Named
@Scope("prototype")
public class Application {
			@Value("User Login")
			private String applicationname;
			@Inject
			private ApplicationUser applicationuser;
			@Inject
			@Named("appowner2")
            private ApplicationOwner applicationowner;
          
        	public void setApplicationname(String applicationname) {
				this.applicationname = applicationname;
			}
        	
        	@Inject
            public void setApplicationuser(ApplicationUser applicationuser) {
				this.applicationuser = applicationuser;
				System.out.println("setter for application user invoked");
			}
        	
        	   //orbitrary method
        	@Inject
    		public void assign(ApplicationUser applicationuser) {
    			this.applicationuser = applicationuser;
    			System.out.println("orbitrary method for application user invoked");
    		}
			/*public Application(ApplicationUser applicationuser) {
				super();
				this.applicationuser = applicationuser;
				System.out.println("constructor for application user invoked");
			}*/
        	@Inject
			@Named("appowner1")
			public void access(ApplicationOwner applicationowner) {
				 System.out.println("orbitrary method for application owner invoked");
					this.applicationowner = applicationowner;
				}
        	@Inject
			@Named("appowner2")
			public Application(ApplicationOwner applicationowner) {
				super();
				this.applicationowner = applicationowner;
				System.out.println("owner is injecting by constructor");
			}

			
			
			@Override
			public String toString() {
				return "Application [applicationname=" + applicationname + ", applicationuser=" + applicationuser
						+ ", applicationowner=" + applicationowner + "]";
			}				
}