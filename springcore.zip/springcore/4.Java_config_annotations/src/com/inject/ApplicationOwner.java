package com.inject;

public class ApplicationOwner {
			
			private String ownername;

			public void setOwnername(String ownername) {
				this.ownername = ownername;
			}

			@Override
			public String toString() {
				return "ApplicationOwner [ownername=" + ownername + "]";
			}
}
