package com.cdi.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.cdi.beans.Course;
import com.cdi.beans.Meeting;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
BeanFactory factory=new XmlBeanFactory(new ClassPathResource("com/cdi/common/application-context.xml"));
	Meeting meeting=factory.getBean("meeting",Meeting.class);
	//System.out.println(meeting);
	
	factory = new XmlBeanFactory(new ClassPathResource(
			"com/cdi/common/application-config.xml"));
	
	 Course course = factory.getBean("btech1Yr1SemCS", Course.class);
	 System.out.println(course);
	 
	//University university = factory.getBean("university", University.class);
	//System.out.println(university);
	}

}
