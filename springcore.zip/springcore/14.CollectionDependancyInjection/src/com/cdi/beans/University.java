package com.cdi.beans;

import java.util.Map;
import java.util.Properties;

public class University {
	private Map<String, Course> hodToCourseMap;
	private Properties courseToppers;

	public University(Map<String, Course> hodToCourseMap) {
		this.hodToCourseMap = hodToCourseMap;
	}

	public void setCourseToppers(Properties courseToppers) {
		this.courseToppers = courseToppers;
	}

	@Override
	public String toString() {
		return "University [hodToCourseMap=" + hodToCourseMap
				+ ", courseToppers=" + courseToppers + "]";
	}

}
