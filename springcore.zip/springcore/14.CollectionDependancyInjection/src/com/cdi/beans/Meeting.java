package com.cdi.beans;

import java.util.List;

public class Meeting {
		private List<String> todo;

//		public void setTodo(List<String> todo) {
//			this.todo = todo;
//		}
		
		public Meeting(List<String> todo) {
			super();
			this.todo = todo;
		}
		@Override
		public String toString() {
			return "Meeting [todo=" + todo + "]";
		}		
}
