package com.ci.beans;

public class HondaEngine implements IEngine{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("Honda engine started");
	}
}
