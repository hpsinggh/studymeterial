package com.ci.beans;

public class NissanEngine implements IEngine{
	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println(" Nissan engine started");
	}
}
