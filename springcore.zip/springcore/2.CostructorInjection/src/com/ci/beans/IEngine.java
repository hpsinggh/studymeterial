package com.ci.beans;

public interface IEngine {
	public void start();
}
