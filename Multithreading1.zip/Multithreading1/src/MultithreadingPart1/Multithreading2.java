/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultithreadingPart1;

/**
 *
 * @author heerendra.singh
 */
class MyThread extends Thread {

	MyThread(String threadName) {
		super(threadName);
	}

	public void run() {
		for (int i = 0; i <= 20; i++) {
			System.out.println("execute thread: " + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ex) {
				System.err.println("exception arise during thread execution " + ex);
			}
		}
	}
}

public class Multithreading2 {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		Thread thread = new MyThread("MyThread");
		thread.start();

		for (int i = 0; i <= 20; i++) {
			System.out.println("execute thread: " + Thread.currentThread().getName());
			try {
				thread.sleep(1000);
			} catch (InterruptedException ex) {
				System.err.println("exception arise during thread execution " + ex);
			}
		}

	}
}

//If your class provides more functionality rather than just running as Thread, you should implement Runnable interface to provide a way to run it as Thread.
//If your class only goal is to run as Thread, you can extend Thread class.
//Implementing Runnable is preferred because java supports implementing multiple interfaces.
//If you extend Thread class, you can’t extend any other classes.
