/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultithreadingPart1;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author heerendra.singh
 */
//Difference between notify() and notifyAll() in Java
class Thread1 implements Runnable {

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + ": starts");
		synchronized (this) {
			try {
				this.wait();
			} catch (InterruptedException ex) {
				Logger.getLogger(Thread1.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
		System.out.println(Thread.currentThread().getName() + ": notified");
	}
}

class Thread2 implements Runnable {

	private Thread1 thread1;

	public Thread2(Thread1 thread1) {
		this.thread1 = thread1;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + ": starts");
		synchronized (this.thread1) {
			try {
				this.thread1.wait();
			} catch (InterruptedException ex) {
				Logger.getLogger(Thread1.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
		System.out.println(Thread.currentThread().getName() + ": notified");
	}
}

class Thread3 implements Runnable {

	private Thread1 thread1;

	public Thread3(Thread1 thread1) {
		this.thread1 = thread1;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + ": starts");
		synchronized (this.thread1) {
			this.thread1.notify(); //or notifyAll();
		}
		System.out.println(Thread.currentThread().getName() + ": notified");
	}
}

public class Multithreading5 {

	public static void main(String[] args) throws InterruptedException {
		Thread1 thread = new Thread1();
		Thread thread1 = new Thread(thread, "Thread-1");
		Thread thread2 = new Thread(new Thread2(thread), "Thread-2");
		Thread thread3 = new Thread(new Thread3(thread), "Thread-3");
		thread1.start();
		thread2.start();
		Thread.sleep(100);
		thread3.start();

	}
}

/*
We can use notify() method to give the notification for only one thread which is waiting for a particular object
whereas by the help of notifyAll() methods we can give the notification to all waiting threads of a particular object.
 */
/*
https://www.geeksforgeeks.org/difference-notify-notifyall-java/
*/
