/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultithreadingPart1;

/**
 *
 * @author heerendra.singh
 */
class CustomRunnable implements Runnable {

	public void run() {
		for (int i = 0; i <= 10; i++) {
			System.out.println("execute thread: " + Thread.currentThread().getName());
			try {
				Thread.sleep(500);
			} catch (InterruptedException ex) {
				System.err.println("exception arise during thread execution " + ex);
			}
		}
	}
}

public class Multithreading3 {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		Runnable runnable = new CustomRunnable();
		Thread thread1 = new Thread(runnable, "Thread1");
		Thread thread2 = new Thread(runnable, "Thread2");
		Thread thread3 = new Thread(runnable, "Thread3");
		thread1.start();
		try {
//           start others thread only when first thread is dead
			thread1.join();

//             start second thread after waiting for 2 seconds or if it's dead
//            thread1.join(2000);
//          let all threads finish execution before finishing main thread
//            thread1.join();
//            thread2.join();
//            thread3.join();
		} catch (InterruptedException ex) {
			System.err.println("Exception arises : " + ex);
		}
		thread2.start();
		thread3.start();
		for (int i = 0; i <= 10; i++) {
			System.out.println("execute thread: " + Thread.currentThread().getName());
			try {
				Thread.sleep(500);
			} catch (InterruptedException ex) {
				System.err.println("exception arise during thread execution " + ex);
			}
		}
	}
}
