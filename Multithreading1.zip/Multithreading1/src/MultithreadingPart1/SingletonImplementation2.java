/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultithreadingPart1;

/**
 *
 * @author heerendra.singh
 */
//1
class EagerInitializedSingleton {

	private static final EagerInitializedSingleton instance = new EagerInitializedSingleton();

	//private constructor to avoid client applications to use constructor
	private EagerInitializedSingleton() {
	}

	public static EagerInitializedSingleton getInstance() {
		return instance;
	}
}

//2
class StaticBlockSingleton {

	private static StaticBlockSingleton instance;

	private StaticBlockSingleton() {
	}

	//static block initialization for exception handling
	static {
		try {
			instance = new StaticBlockSingleton();
		} catch (Exception e) {
			throw new RuntimeException("Exception occured in creating singleton instance");
		}
	}

	public static StaticBlockSingleton getInstance() {
		return instance;
	}
}

//3
class LazyInitializedSingleton {

	private static LazyInitializedSingleton instance;

	private LazyInitializedSingleton() {
	}

	public static LazyInitializedSingleton getInstance() {
		if (instance == null) {
			instance = new LazyInitializedSingleton();
		}
		return instance;
	}
}

//4
class ThreadSafeSingleton {

	private static ThreadSafeSingleton instance;

	private ThreadSafeSingleton() {
	}

	public static synchronized ThreadSafeSingleton getInstance() {
		if (instance == null) {
			instance = new ThreadSafeSingleton();
		}
		return instance;
	}

}

//5
/*
public static ThreadSafeSingleton getInstanceUsingDoubleLocking(){
    if(instance == null){
        synchronized (ThreadSafeSingleton.class) {
            if(instance == null){
                instance = new ThreadSafeSingleton();
            }
        }
    }
    return instance;
}
 */

 /*
Each time we want to get the instance of our singleton, we need to acquire a potentially unnecessary lock.
To fix that, we could instead start by verifying if we need to create the object in the first place and only in that case we would acquire the lock.
Going further, we want to perform the same check again as soon as we enter the synchronized block, in order to keep the operation atomic.
 */
//https://www.journaldev.com/171/thread-safety-in-java-singleton-classes-with-example-code
//https://www.journaldev.com/1377/java-singleton-design-pattern-best-practices-examples
//https://www.baeldung.com/java-singleton-double-checked-locking
//https://www.geeksforgeeks.org/volatile-keyword-in-java/
