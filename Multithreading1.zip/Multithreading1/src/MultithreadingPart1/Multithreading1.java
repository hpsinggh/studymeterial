/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultithreadingPart1;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author heerendra.singh
 */
class MyRunnable implements Runnable {

    public void run() {
        for (int i = 0; i <= 20; i++) {
            System.out.println("execute thread: " + Thread.currentThread().getName());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                System.err.println("exception arise during thread execution "+ ex);
            }
        }
    }
}

public class Multithreading1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Runnable runnable = new MyRunnable();
        Thread thread = new Thread(runnable); //,"My-Thread"
        thread.start();

        for (int i = 0; i <= 20; i++) {
            System.out.println("execute thread: " + Thread.currentThread().getName());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                System.err.println("exception arise during thread execution "+ ex);
            }
        }

    }
}
