/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultithreadingPart1;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author heerendra.singh
 */
//data inconsistency example
class Utility {

	public void wish(String name) throws InterruptedException {
		synchronized (this) {
			for (int i = 0; i <= 5; i++) {
				System.out.print("Good Morning: ");
				Thread.sleep(1000);
				System.out.println(name);
			}
		}
	}
}

class CustomizeThread implements Runnable {

	private Utility utility;
	private String name;

	public CustomizeThread(Utility utility, String name) {
		this.utility = utility;
		this.name = name;
	}

	@Override
	public void run() {
		try {
			utility.wish(name);
		} catch (InterruptedException ex) {
			Logger.getLogger(CustomizeThread.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

}

public class Multithreading6 {

	public static void main(String[] args) {
		Utility utility = new Utility();
		Thread thread1 = new Thread(new CustomizeThread(utility, "Heerendra"), "Thread-1");
		Thread thread2 = new Thread(new CustomizeThread(utility, "Manan"), "Thread-2");
		thread1.start();
		thread2.start();
	}
}
