/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultithreadingPart1;

/**
 *
 * @author heerendra.singh
 */
// this can lead to data inconsistency when the threads are used to read and update the shared data.
//it requires three steps; first to read the current value, second to do the necessary operations to get the updated value
//and third to assign the updated value to the field reference.
//sometimes both thread update the same count value and data inconsistancy occurs.
class CustomThread implements Runnable {

	private int count; //shared data between threads.

	public void run() {
		for (int i = 1; i < 5; i++) {
			try {
				Thread.sleep(500);
//                System.out.println("Thread executes: "+ Thread.currentThread().getName());
				process(i);
			} catch (InterruptedException ex) {
				System.err.println("exception arise during thread execution " + ex);
			}
		}
	}

	public int getCount() {
		return count;
	}

	public void process(int i) {
		try {
			Thread.sleep(i * 1000);
			synchronized (this) {
				System.out.println("Thread executes: " + Thread.currentThread().getName());

				count++;
			}
		} catch (InterruptedException ex) {
			System.err.println("exception in process() :" + ex);
		}
	}
}

public class Multithreading4 {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		CustomThread customThread = new CustomThread();
		Thread thread1 = new Thread(customThread, "Thread1");
		Thread thread2 = new Thread(customThread, "Thread2");
		thread1.start();
		thread2.start();
		try {
			thread1.join();
			thread2.join();
		} catch (InterruptedException ex) {
			System.err.println("Exception arises : " + ex);
		}
		System.out.println("total is " + customThread.getCount());
	}
}


/*
Thread safety in java is the process to make our program safe to use in multithreaded environment, there are different ways
through which we can make our program thread safe.

*Synchronization is the easiest and most widely used tool for thread safety in java.
*Use of Atomic Wrapper classes from java.util.concurrent.atomic package. For example AtomicInteger
*Use of locks from java.util.concurrent.locks package.
*Using thread safe collection classes, check this post for usage of ConcurrentHashMap for thread safety.
*Using volatile keyword with variables to make every thread read the data from memory, not read from thread cache.
 */


//https://www.journaldev.com/1061/thread-safety-in-java
