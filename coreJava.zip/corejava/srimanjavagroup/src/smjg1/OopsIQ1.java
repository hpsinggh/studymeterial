package smjg1;

public class OopsIQ1 {
public void method(Integer i)
{
System.out.println("Double parameterize method");
}
public void method(String i)
{
System.out.println("String parameterize method");
}
public void method(OopsIQ1 i)
{
System.out.println("Integer parameterize method");
}
	public static void main(String[] args) {
		new OopsIQ1().method((Integer)null);
		//if u pass null,ambiguity will be there if u pass null
		
	}

}
