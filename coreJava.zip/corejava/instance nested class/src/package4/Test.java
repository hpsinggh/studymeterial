package package4;

import package4.InstanceNest;
import package4.InstanceNest.Inner;

public class Test {
	public static void main(String[] args) {
		InstanceNest in= new InstanceNest();
		InstanceNest.Inner inner = in.new Inner();
		inner.method();
	}
}
