package package4;

public class InstanceNest {
	
	String x="instanace data member Outer class.";  

	 class Inner {
		 String x="instanace data member inner class.";  
		public void method()
		{   
			String x="local variable of method";
			System.out.println(InstanceNest.this.x);
		}
		
	}
}
