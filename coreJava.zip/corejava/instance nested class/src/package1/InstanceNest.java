package package1;

public class InstanceNest {
	// Simple nested inner class
	   class Inner {
	      public void method() 
	      {
	           System.out.println("enters in inner class");
	      }
	   }
}
