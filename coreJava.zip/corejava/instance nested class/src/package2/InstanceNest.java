package package2;

public class InstanceNest {
	int x;     
	
	static int y;  

	class Inner {
		 String a="Instance data member of static nested class.";
		/*static String b="static data member of Inner class.";
		public static void method1()
		{
			b="value of static data member has been change.";
			System.out.println(b);
		}*/
		public void method2()
		{
			System.out.println(a);
			a="value of instance data member has been change.";
			System.out.println(a);
		}
		
	}
}
