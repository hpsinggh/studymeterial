package package4;

public class LocalInner {
	static String a="static data member of outer class.";
	String b="instance data member of outer class.";
	   static void outerMethod() {
	    	String c="local varible of outer class method";
	        class Inner {
	        	String d="instance data member of local Inner class.";
	        	//static data member of inner class will access or not?
	            void innerMethod() {
	            	String e="local varible of local Inner class method";
//	                System.out.println(a);
//	                System.out.println(b);
//	                System.out.println(c);
//	                System.out.println(d);
//	                System.out.println(e);
	            }
	        }
	        Inner y = new Inner();
	        y.innerMethod();
	    }
}


//local inner class can be final ,strictfp,abstract only