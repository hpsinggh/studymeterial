package package1;

public class LocalInner {
	    void outerMethod1() {
	        System.out.println("inside outerMethod1");
	        class Inner {
	            void innerMethod() {
	                System.out.println("inside innerMethod");
	            }
	        }
	        Inner y = new Inner();
	        y.innerMethod();
	    }
	    void outerMethod2()
	    {
	    	System.out.println("inside OuterMethod2");
	    	outerMethod1();
	    }
}
