package Array;
import java.util.Arrays;
public class MyArray1 {
	public static void printArray(int[] a)
	{
		System.out.print("arrays printing by method:");
		for(int value:a)
		 System.out.print(" "+value);
	}
	public static void main(String[] args) {
	  String[] s={"hirendra","gurpreet","anita","arjun"}; //Representation style 1
	  System.out.println(s[0]+" "+s[1]+" "+s[2]+" "+s[3]);
	  int[] x=new int[100];    //representation style 2
	  for(int i=1;i<=x.length;i++)  //Scanning
		  x[i-1]=i;
	  for(int value:x)//printing
	  System.out.println(value);
	  int sum=0;   //summing
	  for(int i=0;i<=x.length-1;i++)
		  sum=sum+x[i];
	  System.out.println("total is:"+sum);
	  //finding largest//smallest element
	  int max=x[0];
	  for(int i=0;i<=x.length-1;i++)
		  if(max<x[i])max=x[i];
	  System.out.println("max no is:"+max);
	  Arrays.sort(x);//or
	  System.out.println("max no by using Arrays class:"+x[x.length-1]);
	  //calling of a method by passing array
	  printArray(new int[]{10,20,30,40,50,60,70,80,90,100});
	}
}