package Array;

public class ArrayIQ {
public static void main(String[] args) {
	//find the missing number in integer array of 1 to 100
	/*calculate sum of all numbers in the array and compare with expected sum,
	the difference would be the missing number*/
	int[] array={1,2,3,4,5};
	int i,total=0;
	for(i=0;i<array.length;i++)
	{	
	total=total+array[i];
		
	}
	System.out.println(total);
}
}
