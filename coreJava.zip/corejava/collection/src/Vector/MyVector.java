package Vector;

import java.util.Vector;

public class MyVector {
		public static void main(String[] args) {
			Vector object=new Vector();
			object.add(10);
			object.add(0,20);
			object.addElement("hi");
			object.addElement("hello");
			object.addElement("bye");
			System.out.println(object);
			/*object.remove("hi");
			object.remove(3);
			object.removeElement("hello");
			System.out.println(object);	
			System.out.println(object.get(0));
			System.out.println(object.elementAt(1));*/
		}
}
