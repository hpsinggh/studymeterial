package collectionIQ;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.TreeSet;

public class CollectionIQ4 {
	public static void listSort()
	{
		ArrayList list=new ArrayList();
		list.add("z");
		list.add("o");
		list.add("r");
		list.add("a");
		list.add("b");
		System.out.println(list);//preserve order
		Collections.sort(list);
		System.out.println(list);//ascending sorting
		Collections.sort(list,new MyComparator());
		System.out.println(list);//Customize descending sorting
	}
	public static void MapShorting()
	{
		TreeMap map=new TreeMap(new MyComparator());
		map.put("z",8);
		map.put("y",9);
		map.put("m",5);
		map.put("n",4);
		map.put("a",1);
		map.put("b",2);
		System.out.println(map);
	}
	public static void main(String[] args) {
		TreeSet set = new TreeSet(new MyComparator());
		set.add("z");
		set.add("o");
		set.add("r");
		set.add("a");
		set.add("b");
		//System.out.println(set);
		//MapShorting();
		listSort();
	}
}

class MyComparator implements Comparator {
	public int compare(Object o1, Object o2) {
		String s1 = o1.toString();
		String s2 = (String) o2;
		return s2.compareTo(s1);
	}
}
