package collectionIQ;

import java.util.HashSet;
import java.util.Set;
//how to use remove method
class CollectionIQ3 {

		    public static void main(String[] args) {
		        Set<Short> set = new HashSet<Short>();
		 
		        for (Short i = 0; i < 10; i++) {
		            set.add(i);
		            
		        }

		      /*  for (Short i = 0; i < 10; i++) {
		        	 set.add(i);//set.add(new Short(i));
		            System.out.println(set.remove(new Short((short) (i))));
		           or //set.remove((short)(i - 1));
		        }*/
		        System.out.println(set.size());
		        System.out.println(set);
		    }
		 
		}
//because set doesn't have any method so remove of collection will get execute.
//which returns true if entered value is Object class type or same class Type (means Short class Type)
//in case of intger type collection it should be Integer class type object,or u also can pass value but in 
//integer type of collection integer value can pass directly but in case of byte collection we first type cast int into byte
//otherwise it will not remove the value and simple returns false.
