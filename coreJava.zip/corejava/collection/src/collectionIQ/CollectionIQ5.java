package collectionIQ;

import java.util.TreeSet;

class Employee implements Comparable{
	private int age;
	private String name;

	public Employee(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	public int compareTo(Object o) {
		int age1=this.age;
		Employee e=(Employee)o;
		int age2=e.age;
		if(age1<age2)
			return -1;
		else if(age1>age2)
			return 1;
		else 
			return 0;
	}
	@Override
	public String toString() {
		return "Employee [age=" + age + ", name=" + name + "]";
	}
}
public class CollectionIQ5
{
	public static void main(String[] args) {
		TreeSet set=new TreeSet();
		set.add(new Employee(21,"Hirendra"));
		set.add(new Employee(2,"Yuvan"));
		set.add(new Employee(5,"Anita"));
		set.add(new Employee(25,"Gurpreet"));
		System.out.println(set);
	}
}
