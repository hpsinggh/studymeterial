package collectionIQ;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
//print duplicate elements of arraylist
//print duplicate elements no occurance 
public class CollectionIQ2 {
	static List<String> list=new ArrayList<String>();
	public static void main(String[] args) {
		list.add("kittu");
		list.add("meet");
		list.add("rabby");
		list.add("tinni");
		list.add("kittu");
		list.add("rabby");
		
		/*Set<String> set=new HashSet<String>();
		for(String  name:list)
		{
			if(set.add(name)==false)
				System.out.println(name);
		}*/
		/*	Set<String> set=new HashSet<String>(list);
		for (String name : set) {
		    System.out.println(name + ": " + Collections.frequency(list, name));
		}*/
		//to search element in list.
		//System.out.println(Collections.binarySearch(list,"rabby"));
		/*System.out.println(list);
	    Collections.reverse(list);
	    System.out.println(list);*/
	}
}
