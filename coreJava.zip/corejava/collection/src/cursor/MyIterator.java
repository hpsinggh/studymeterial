package cursor;

import java.util.ArrayList;
import java.util.Iterator;

public class MyIterator {

	public static void main(String[] args) {
		ArrayList object=new ArrayList();
		for(int i=0;i<=9;i++)
		{
			object.add(i);
		}
		Iterator i=object.iterator();
		while(i.hasNext())
		{
			int value=(int)i.next();
			if(value%2==0)
				i.remove();
		}
		System.out.println(object);

	}

}
