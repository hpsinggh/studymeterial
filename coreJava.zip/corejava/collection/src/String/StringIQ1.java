package String;
//Reverse a string
public class StringIQ1 {

	public static void main(String[] args) {
		String s="Hello hi how are you"; //by converting it in char array
		char[] array=s.toCharArray();
		for(int i=s.length()-1;i>=0;i--)
		{
		//	System.out.print(array[i]);
		}
		StringBuffer stringBuffer=new StringBuffer("");//by converting it in string buffer
		stringBuffer=stringBuffer.append(s);
		//System.out.println(stringBuffer.reverse());
		for(int i=s.length()-1;i>=0;i--)  //direct reverse the string
			System.out.print(s.charAt(i));
	}

}
