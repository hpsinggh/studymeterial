package hashmap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
//concurrent modification exception 
//that iterator is fail fast,while in the same case of
//concurrent HashMap Iterator is fail safe
public class HashMapIQ1 extends Thread{
		static HashMap<Integer,String> map=new HashMap<Integer,String>();
		public void run()
		{
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("child thread updating map");
			map.put(3, "bye");
		}
		public static void main(String[] args) {
			map.put(1,"Hi");
			map.put(2,"hello");
			//create object of thread.
			HashMapIQ1 thread=new HashMapIQ1();
			thread.start();
			Set key=map.keySet();
			Iterator iterator=key.iterator();//map.keySet().iterator();
			while(iterator.hasNext())
			{
				//Integer i=Integer.valueOf((String) iterator.next());
				//int i=(int)iterator.next();
				Integer i=(Integer)iterator.next();
				System.out.println("value"+i+":"+map.get(i));
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(map);
	}
}