package hashmap;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
//insert 2 list object in Map one all value as key 
//and another list all value as a value in map with single iteration.
public class HashMapIQ5 {
public static void main(String[] args) {
	List list1=Arrays.asList("apple,banana,orange".split(","));
	List list2=Arrays.asList("90,40,70".split(","));
	Map map=new LinkedHashMap();
	Iterator itr1=list1.iterator();
	Iterator itr2=list2.iterator();
	while(itr1.hasNext() && itr2.hasNext())
	{
		map.put(itr1.next(),itr2.next());
	}
	System.out.println(map);
}
}
