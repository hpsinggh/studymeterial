import java.awt.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
class Frame1 extends Frame
{
    Button b1=new Button("Click 1");
    Button b2=new Button("Click 2");
    Button b3=new Button("Click 3");
    Button b4=new Button("Click 4");
    Button b5=new Button("Click 5");
    Button b6=new Button("Click 6");
    CardLayout c;
    public Frame1()
    {
		c=new CardLayout(20,20);
		this.setLayout(c);
		this.setSize(500,400);
		this.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){System.exit(0);}});
		this.add("K1",b1);
		this.add("K2",b2);
		this.add("K3",b3);
		this.add("K4",b4);
		this.add("K5",b5);
		this.add("K6",b6);
		b1.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){b1_Click();}});
		b2.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){b1_Click();}});
		b3.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){b1_Click();}});
	}
	void b1_Click()
	{
		c.show(this,"K5");
	}
}
class p80
{
	public static void main(String args[]) {
	        new Frame1().setVisible(true);
	}
}

