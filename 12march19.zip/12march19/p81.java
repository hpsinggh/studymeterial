import java.awt.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
class Frame1 extends Frame
{
    public Frame1()
    {
		this.setLayout(new CardLayout(10,10));
		this.setSize(400,300);
		this.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){System.exit(0);}});
		Panel p1=new Panel();
		//p1.setBackground(Color.RED);
		this.add("K1",p1);
		p1.setLayout(new BorderLayout(0,20));
		TextField t1=new TextField();
		p1.add(t1,BorderLayout.NORTH);
		Panel p2=new Panel();
		//p2.setBackground(Color.GREEN);
		p1.add(p2);
		p2.setLayout(new GridLayout(5,8,3,3));
		for(int i=1;i<=40;i++)
		{
			Button b=new Button(i+"");
			p2.add(b);
		}
	}
}
class p81
{
	public static void main(String args[]) {
	        new Frame1().setVisible(true);
	}
}

