public class Multithreading2 {
	public void run() {
		System.out.println("thread is running...");
	}

	public static void main(String args[]) {
		Multithreading2 m1 = new Multithreading2();
		Thread t1 = new Thread(); // registration
		t1.start();
		Thread t2 = new Thread(); // data sharing of same class between multiple threads
		t2.start();
		Thread t3 = new Thread(); // data sharing of same class between multiple threads
		t3.start();

	}
}