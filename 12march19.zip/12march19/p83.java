class Shared
{
	int x=5;
}
class Thread1 extends Thread
{
	Shared s;
	Thread1(Shared s1)
	{
		s=s1;
	}
	public void run()
	{
		synchronized(s)
		{
			Thread t=Thread.currentThread();
			System.out.print("Start:"+t.getName());
			System.out.print(" [");
			int y=s.x*10;
			s.x=y;
			System.out.print(" X=");
			System.out.print(s.x);
			System.out.print(" ] ");
			System.out.println(" End:"+t.getName());
		}

	}
}
class Thread2 extends Thread
{
	Shared s;
	Thread2(Shared s1)
	{
		s=s1;
	}
	public void run()
	{
		synchronized(s)
		{
			Thread t=Thread.currentThread();
			System.out.print("Start:"+t.getName());
			System.out.print(" [");
			int y=s.x+3;
			s.x=y;
			System.out.print(" X=");
			System.out.print(s.x);
			System.out.print(" ] ");
			System.out.println(" End:"+t.getName());
		}
	}
}
class p83
{
	static
	{
		Shared s=new Shared();
		Thread1 t1=new Thread1(s);
		Thread2 t2=new Thread2(s);
		t1.setName("T1");t2.setName("T2");
		t1.start();
		t2.start();
	}
}

