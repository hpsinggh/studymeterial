package cursor;

import java.util.Enumeration;
import java.util.Vector;
import java.util.concurrent.SynchronousQueue;

public class MyEnumeration {
public static void main(String[] args) {
	Vector object=new Vector();
	for(int i=0;i<=9;i++)
		object.addElement(i);
		Enumeration en=object.elements();
		while(en.hasMoreElements())
		{
			int x=(int) en.nextElement();
		if(x%2==0)
			System.out.println(x);
		}
		}
}
