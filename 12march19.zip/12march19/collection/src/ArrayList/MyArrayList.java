package ArrayList;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.RandomAccess;

public class MyArrayList {

	public static void main(String[] args) {
		ArrayList object = new ArrayList();
		object.add(10);
		object.add(20);
		object.add("Ram");
		object.add(40);
		object.add(null);
		object.add(0,100);
		//object.set(0,200);
		Object o=object.remove(1);
		System.out.println(object);
		//Object ob=object.get(3);
		//System.out.println(ob);
		//Collection c=object;
		//System.out.println(c);
		//System.out.println(object instanceof RandomAccess);
	}
}
