/*
public class FinallyBlock {
	public static void main(String[] a) {
		try {
			int i = 10 / 0;
			System.out.println("inside first try block");
		} 
		catch (Exception ex) {
			System.out.println("Inside 1st catch Block");
		} 
		finally {
			System.out.println("Inside 1st finally block");
		}

		try {
			int i = 10 / 10;
			System.out.println("inside second try block");
		} 
		catch (Exception ex) {
			System.out.println("Inside 2nd catch Block");
		} 
		finally {
			System.out.println("Inside 2nd finally block");
		}
	}
}
*/
/*
class FinallyBlock
{
   public static int myMethod()
   {
       try {
            //try block
            return 0;
       }
       finally {
            //finally
            System.out.println("Inside Finally block");
       }
  }
  public static void main(String args[])
  {
       System.out.println(FinallyBlock.myMethod());
  }
}
*/
/*
public class FinallyBlock {

    public static int test(int i) {
        try {
            if (i == 0)
                throw new Exception();
            return 0;
        } catch (Exception e) {
            return 1;
        } finally {
            return 2;
        }
    }

    public static void main(String[] args) {
        System.out.println(test(0));
        System.out.println(test(1));
    }
}
*/
/*
public class FinallyBlock {

    public static int test(int i) {
        try {
            if (i == 0)
                throw new Exception();
            System.out.println("inside try block");
            return 0;
            
        } catch (Exception e) {
        	System.out.println("inside catch block");
            System.exit(0);
            
        } finally {
            System.out.println("inside finally block");
        	return 2;
            
        }
    }

    public static void main(String[] args) {
        //System.out.println("Return value is :"+test(0));
       System.out.println("Return value is :"+test(1));
    }
}
*/

