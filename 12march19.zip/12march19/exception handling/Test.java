//custom exception

class InvalidAgeException extends Throwable{  
 InvalidAgeException(String s){  
  super(s);  
 }  
}  
class Validations{  
  
   static void ageValidate(int age)throws InvalidAgeException{  
     if(age<18)  
      throw new InvalidAgeException("Entered age is not a Valid age");  
     else  
      System.out.println("welcome to vote");  
   }
}
class Test
{
   public static void main(String[] args) { 
	  Validations validation=new Validations();
      try
      {  
    	  validation.ageValidate(13);  
      }
      catch(Throwable m)
      {
    	  System.out.println("Exception occured: "+m);
      }  
      
      System.out.println("..........\n...........\n rest of the code");  
  }  
}  