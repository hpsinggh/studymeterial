package com.cns.SpringMVC_Hib_CURD;

import org.springframework.web.servlet.view.InternalResourceViewResolver;
public class Test {

	
}
