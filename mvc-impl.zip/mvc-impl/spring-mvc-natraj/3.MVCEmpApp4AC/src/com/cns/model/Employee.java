package com.cns.model;

public class Employee {

	private String ename;
	private int eage;
	private int esalary;
	
	public Employee() {
		super();
	}
	public Employee(String ename, int eage, int esalary) {
		super();
		this.ename = ename;
		this.eage = eage;
		this.esalary = esalary;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEage() {
		return eage;
	}
	public void setEage(int eage) {
		this.eage = eage;
	}
	public int getEsalary() {
		return esalary;
	}
	public void setEsalary(int esalary) {
		this.esalary = esalary;
	}
	@Override
	public String toString() {
		return "Employee [ename=" + ename + ", eage=" + eage + ", esalary=" + esalary + "]";
	}
	
}
