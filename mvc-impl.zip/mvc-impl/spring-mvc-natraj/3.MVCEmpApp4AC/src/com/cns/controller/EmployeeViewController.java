package com.cns.controller;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.cns.model.Employee;

public class EmployeeViewController extends AbstractController{
	private Employee emp;
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		//i didn't implement that example completely because that example contain spring JDBC.
		String name="amit kumar";
		Integer age=new Integer(10);
		double salary=20000;
		List empList=new ArrayList();
		empList.add(name);
		empList.add(age);
		empList.add(salary);
		emp=new Employee();
		emp.setEage(22);
		emp.setEname("hierandra singh");
		emp.setEsalary(35000);
		System.out.println(emp);
		Map<String, Object> object=new HashMap<String, Object>();
		object.put("emplist1",empList);
		object.put("emplist2",emp);
		List listOfEmpObj=new ArrayList();
		listOfEmpObj.add(new Employee("Anita kaur",55,50000));
		listOfEmpObj.add(new Employee("Arjun Singh",65,57000));
		object.put("emplist3",listOfEmpObj);
		ModelAndView modelandview=new ModelAndView("Employee",object);
	    return modelandview;
	    
	}

}
