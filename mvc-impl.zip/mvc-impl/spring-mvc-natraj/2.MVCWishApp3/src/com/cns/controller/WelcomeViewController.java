package com.cns.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.cns.service.WishIntf;

public class WelcomeViewController extends AbstractController{

	private WishIntf obj;
	public WelcomeViewController(WishIntf obj) {
		super();
		this.obj = obj;
	}

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		String msg=null;
		msg=obj.generateWishMassage();
		ModelAndView modelandview= new ModelAndView("Welcome","wish",msg);
		return modelandview;
	}

}
