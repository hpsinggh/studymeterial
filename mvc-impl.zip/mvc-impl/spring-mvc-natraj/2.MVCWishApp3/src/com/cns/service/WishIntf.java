package com.cns.service;

public interface WishIntf {
public String generateWishMassage();
}
