package com.cns.service;

import java.util.Calendar;

public class WishClass implements WishIntf {

	@Override
	public String generateWishMassage() {
		int hr=0;
		String msg;
		Calendar cl = Calendar.getInstance();
		hr=cl.get(Calendar.HOUR_OF_DAY);
		if(hr<=11)
			msg = "Gud Morning Sir";
		else if(hr<=15)
			msg = "Gud Evening Sir";
		else if(hr<=20)
			msg="Gud Evening Sir";
		else
			msg="Gud Night Sir";
		return msg;
	}
}
