package com.cns.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
@Controller
public class ViewCnsController extends AbstractController{

	@RequestMapping(value="/cnshome")
	protected ModelAndView handleRequestInternal(HttpServletRequest req, HttpServletResponse arg1) throws Exception {
		String fname=null;
		String lname=null;
		fname=req.getParameter("fname");
		lname=req.getParameter("lname");
		Map<String, String> obj=new HashMap<String, String>();
		String msg="Welcome you "+fname+" "+lname;
		obj.put("message", msg);
		return new ModelAndView("welcome",obj);
	}
}
