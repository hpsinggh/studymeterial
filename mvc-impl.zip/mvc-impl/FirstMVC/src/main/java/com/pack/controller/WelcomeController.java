package com.pack.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {
	@RequestMapping("/firstrequest")
	public ModelAndView sayWelcome()
	{
		ModelAndView mav=new ModelAndView("welcome","message","Welcome to spring MVC");
		return mav;
	}
}
