package Hashset;

import java.util.HashSet;
import java.util.LinkedHashSet;


public class MyHashset {

	public static void main(String[] args) {
	LinkedHashSet obj=new LinkedHashSet();
	//HashSet obj=new HashSet();

	obj.add("amit");
	obj.add("32");
	obj.add("A2");
	obj.add("vinit");
	obj.add(null);
	
	//-------------------
	obj.add(12);//heterogeneous elements allowed
	boolean x=obj.add("amit");
	System.out.println(x);
	obj.add(null);

	System.out.println(obj);
	
	}

}
