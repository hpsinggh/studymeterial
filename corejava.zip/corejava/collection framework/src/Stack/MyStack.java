package Stack;

import java.util.Stack;

public class MyStack {
public static void main(String[] args) {
		Stack object = new Stack();
		object.push("A");
		object.push("B");
		object.push("C");
		object.push("D");
		System.out.println(object);
		System.out.println(object.peek());
		System.out.println(object.pop());
		System.out.println(object);
		System.out.println("B is available offset of "+object.search("B"));
}
}
