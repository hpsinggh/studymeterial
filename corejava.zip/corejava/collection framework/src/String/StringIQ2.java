package String;
//String Palindrom
public class StringIQ2 {

	public static Boolean isPalindrom(String s)
	{
		for(int i=0;i<=s.length()/2;i++){
		if(s.charAt(i)!=s.charAt(s.length()-i-1))
		return false;
		}
			return true;
	}
	public static String removeCharacter(String s,char c)
	{
		return s.replaceAll(Character.toString(c),"");
	}
	public static void main(String[] args) {
		Boolean b=isPalindrom("abcdefedcba");
		System.out.println("number is palindrom:"+b);
		String modified=removeCharacter("hello hi how r you",'o');
		System.out.println("after remove character :"+modified);
		System.out.println("hello".equals("hello"));
		System.out.println("hello".compareTo("hello"));//numbers,capital case,small case
		System.out.println("HELLO".equalsIgnoreCase("hello"));
	}

}
