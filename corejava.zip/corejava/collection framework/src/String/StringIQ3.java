package String;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

//program to print all duplicate elements and remove them and print the string in shorting order
public class StringIQ3 {
	public static void eliminateDuplicateChar(String input) {
		String result = "";
		for (int i = 0; i < input.length(); i++) {
			if (!result.contains(String.valueOf(input.charAt(i)))) {
				result += String.valueOf(input.charAt(i));
			}
		}
		System.out.println("eliminate duplicate characters: " + result);
	}

	public static void printDuplicateChar(String s) {
		String duplicates = "";
		for (int i = 0; i < s.length() - 1; i++) {
			for (int j = i + 1; j < s.length(); j++) {
				if (s.charAt(i) == s.charAt(j)) {
					if (!duplicates.contains(String.valueOf(s.charAt(j)))) {
						duplicates += s.charAt(j);

					}
				}
			}
		}
		System.out.println("duplicate characters are " + duplicates);
	}
	// To eliminate duplicate characters from string and print it in shorting
	// order or preserve order

	public static void main(String[] args) {
		String s = "zxvwvvwsturhgfiggedcba";
		char[] ch = s.toCharArray();
		LinkedHashSet linkedSet = new LinkedHashSet();
		HashSet set = new HashSet();
		for (char item : ch) {
			set.add(item);
			linkedSet.add(item);

		}
		System.out.println("elements in shorting order" + set.toString());
		System.out.println("elements in preserved order" + linkedSet.toString());
		// frequency of elements
		HashMap map = new HashMap();
		for (char character : ch)
			map.put(character, ((int) map.getOrDefault(character, 0)) + 1);
		System.out.println(map);
		// Scanner scanner=new Scanner(System.in);
		// String string=scanner.nextLine();
		// //printDuplicateChar(string);
		// eliminateDuplicateChar(string);
	}
}