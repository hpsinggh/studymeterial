package String;

public class StringIQ5 {
//sort a string without any predefine method
	public static void shorting(String s)
	{
		char temp;
		char[] array=s.toCharArray();
		for(int i=0;i<array.length;i++)
		{
			for(int j=0;j<array.length;j++)
			{
				if(array[i] < array[j])
				{
					temp=array[i];
					array[i]=array[j];
					array[j]=temp;
				}
			}
		}
		System.out.println(array);
	}
	public static void main(String[] args) {
		shorting("ighfedcba");
	}

}
