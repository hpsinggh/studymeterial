package TreeSet;

import java.util.TreeSet;

public class MyTreeSet {
	public static void main(String[] args) {
			
			TreeSet object=new TreeSet();
			object.add("Z");
			object.add("D");
			object.add("A");
			object.add("a");
			object.add("2");
			object.add("d");
			object.add("3");
			//-------------
			//object.add(3);//heterogneous element
			//object.add(null);//null insertion not possible here
			//object.add("3");//duplicates not allowed
			//------------
			System.out.println("first element is: "+object.first());
			System.out.println("last element is: "+object.last());
			System.out.println(object.headSet("D"));
		    System.out.println(object.tailSet("Z"));
		
			System.out.println(object);
	}
}
