package TreeSet;

import java.util.Comparator;
import java.util.TreeSet;

//write a program to insert integer object in tree set where insertion order is 
//descending order.
public class MyTreeSet2 {

	public static void main(String[] args) {
		TreeSet object=new TreeSet(new MyComparator());
		object.add(0);
		object.add(15);
		object.add(11);
		object.add(23);
		object.add(7);
		object.add(18);
		
		
		System.out.println(object);
	}
}
class MyComparator implements Comparator
{

	@Override
	public int compare(Object obj1, Object obj2) {
		int i1=(int)obj1;
		int i2=(int)obj2;
		if(i1<i2)
			return 1;
		else if(i1>i2)
			return -1;
		else
			return 0;
	}
	
}
