package hashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class HashMapIQ4 {

	public static void main(String[] args) {
		// TreeMap map=new TreeMap(); //default sorting
		// TreeMap map=new TreeMap(new MyComparator()); //customize sorting on keys
		// custom shorting on values
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("Hirendra", 25000);
		map.put("Gurpreet", 37000);
		map.put("Arjun", 33000);
		map.put("Prateek", 22000);
		map.put("kittu", 22000);
		//System.out.println(map);
		Set<Entry<String,Integer>> set=map.entrySet();
		ArrayList<Entry<String,Integer>> list=new ArrayList<Entry<String,Integer>>(set);
		Collections.sort(list,new Comparator<Entry<String,Integer>>(){
			public int compare(Map.Entry<String,Integer> entry1,Map.Entry<String, Integer> entry2)
			{
			return (entry1.getValue()).compareTo(entry2.getValue());	
			}
		});
		LinkedHashMap linkedhashmap=new LinkedHashMap();
		for(Map.Entry entry:list)
		{
			linkedhashmap.put(entry.getKey(),entry.getValue());
		}
		System.out.println(linkedhashmap);
	}
}

class MyComparator implements Comparator {
	@Override
	public int compare(Object arg0, Object arg1) {
		String s1 = (String) arg0;
		String s2 = (String) arg1;
		return -s1.compareTo(s2);
	}
}
