package hashmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MyHashMap {

	public static void main(String[] args) {
		Map obj=new HashMap();
		obj.put("hello", 10);
		obj.put("hi", 20);
		obj.put("bye", 30);
		obj.put(40, "key and value can be hetrogeneous");
		//System.out.println(obj);
		//System.out.println(obj.keySet());
		//System.out.println(obj.entrySet());
		//System.out.println(obj.values());
		Set entryset=obj.entrySet();
		Iterator i=entryset.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			System.out.println("key is:"+entry.getKey());
			System.out.println("value is:"+entry.getValue());
			if(entry.getKey().equals("hello"))
			entry.setValue(1000);
		}
		System.out.println(obj);
		/*Double i2=Double.valueOf(10);  //to type cast a value into object
		String s1=String.valueOf(10);
		System.out.println(s1);*/
		List<Long> listLong = new ArrayList<Long>();
		//listLong.add(10); //error will be there
		listLong.add((long)10);
		listLong.add(Long.valueOf(20));
		System.out.println(listLong);
		//List<Number> listNumbers = listLong; // compiler error
		/*Why can�t we write code as List<Number> numbers = new ArrayList<Integer>();?
		No,Generics doesn�t support sub-typing*/
		/*
		 Map<String,Integer> obj=new HashMap<String,Integer>();
			obj.put("hello", 10);
			obj.put("hi", 20);
			obj.put("bye", 30);
			obj.put(40, "key and value can be hetrogeneous");//error will be there
			System.out.println(obj);
		  */
		System.out.println("hello java");
		Hashtable object=new Hashtable();
		object.put("key", "value");
		object.put("sweety", null);
		System.out.println(object);
		
	}

}
/*
 internal code of equals
public boolean equals(Object obj) 
{
	return (this == obj);
} 
 */
