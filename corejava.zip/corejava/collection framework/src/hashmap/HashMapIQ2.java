package hashmap;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

class Temp {
	private String name;
	private int rollno;

	public Temp(String name, int rollno) {
		super();
		this.name = name;
		this.rollno = rollno;
	}
}
public class HashMapIQ2 {
	static Map map=new HashMap();
	public static void main(String[] args) {
		/*String s1=new String("hello");
		String s2=new String("hello");
		map.put(s1, "hello");
		map.put("hi","hi");
		map.put("bye", "bye");
		map.put(s2,"helloooooooooo");*/
		Temp t1=new Temp("amit",21);
		Temp t2=new Temp("amit",21);
		map.put(t1,"hello");
		map.put(t2,"hi");
		System.out.println(map);
	}
}
