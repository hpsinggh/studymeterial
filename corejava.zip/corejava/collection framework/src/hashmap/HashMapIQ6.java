package hashmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
//if u have given list u have to make an Map>
//(here deptNo will be one attribute of Employee class)
//solution pending
class Employee implements Comparable
{
private String name;
private int age;
public Employee(String name, int age) {
	super();
	this.name = name;
	this.age = age;
}
@Override
public String toString() {
	return "Employee [name=" + name + ", age=" + age + "]";
}
@Override
public int compareTo(Object obj) {
	Integer age1=this.age;
	Integer age2=((Employee)obj).age;
	return age1.compareTo(age2);
}
}
public class HashMapIQ6 {

	public static void main(String[] args) {
		ArrayList list=new ArrayList();
		list.add(new Employee("Amit",21));
		list.add(new Employee("Hirendra",32));
		list.add(new Employee("Gurneet",28));
		list.add(new Employee("manan",29));
		list.add(new Employee("Gurpreet",30));
		//Collections.sort(list);
		//System.out.println(list);
		HashMap map=new HashMap();
		map.put(deptno,list);
	}

}
