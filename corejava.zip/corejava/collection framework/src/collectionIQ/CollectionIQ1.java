package collectionIQ;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class CollectionIQ1 {
		//concurrent modification exception
		public static void main(String[] args) {
			List al=new ArrayList();
			al.add("Z");
			al.add("A");
			al.add("C");
			al.add("P");
			al.add("5");
			al.add("1");
			System.out.println(al);
			//al.remove("hello");//remove element by collection method
			//al.remove(1);//remove element by list method
			ListIterator itr=al.listIterator();
			while(itr.hasNext())
			{
				String s1=(String)itr.next();
					if(s1.equals("C"))
					itr.remove();
//						al.remove("C");
			}
			System.out.println("after remove element from collection "+al);
			Collections.sort(al);//return type void
			System.out.println("after sorting of collection elements "+al);
		}
}
/*
 * How do you remove an entry from a Collection? and subsequently what is the
 * difference between the remove() method of Collection and remove() method of
 * Iterator, which one you will use while removing elements during iteration?
 * 
 * Collection interface defines remove(Object obj) method to remove objects from
 * Collection. List interface adds another method remove(int index), which is
 * used to remove object at specific index. You can use any of these method to
 * remove an entry from Collection, while not iterating. Things change, when you
 * iterate. Suppose you are traversing a List and removing only certain elements
 * based on logic, then you need to use Iterator's remove() method. This method
 * removes current element from Iterator's perspective. If you use Collection's
 * or List's remove() method during iteration then your code will throw
 * ConcurrentModificationException. That's why it's advised to use Iterator
 * remove() method to remove objects from Collection
 */