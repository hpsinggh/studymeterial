package cursor;

import java.util.LinkedList;
import java.util.ListIterator;

public class MyListIterator {
				public static void main(String[] args) {
					LinkedList object=new LinkedList();
						object.add("amit");
						object.add("nitin");
						object.add("vikas");
						object.add("sumit");
						object.add("suresh");
						ListIterator iterator=object.listIterator();
					while(iterator.hasNext())
					{
						String s=(String)iterator.next();
						if(s.equals("amit"))
							iterator.remove();
						if(s.equals("nitin"))
							iterator.add("kumar");
						if(s.equals("vikas"))
								iterator.set("vikky");
					}
					System.out.println(object);
					while(iterator.hasPrevious())
					{
						String s=(String)iterator.previous();
						System.out.println(s);
					}
				}
}
