package LinkedList;

import java.util.LinkedList;

public class MyLinkedList {
		
	
	public static void main(String[] args) {
		LinkedList list=new LinkedList();
		list.add("hi");
		list.add("hello");
		list.addFirst("a");
		list.addLast("z");
//		System.out.println(list);
//		System.out.println(list.getFirst());
//		System.out.println(list.getLast());
//		System.out.println(list.removeFirst());
//		System.out.println(list);
//		System.out.println(list.removeLast());
		System.out.println(list);
		System.out.println(list.get(1));
	}

}
