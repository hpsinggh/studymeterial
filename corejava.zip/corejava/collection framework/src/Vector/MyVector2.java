package Vector;

import java.util.Vector;

public class MyVector2 {
		public static void main(String[] args) {
			Vector object=new Vector();
			System.out.println("current capacity is: "+object.capacity());
			for(int  i=0;i<=9;i++)
			{
				object.addElement(i);
			}
			System.out.println("current capacity is: "+object.capacity());
			object.addElement(30);
			System.out.println("current capacity becomes "+object.capacity());
			System.out.println(object);
		}
}
