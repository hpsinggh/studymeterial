package package2;
public class Test {
	public static void main(String[] args) {
		InstanceNest in= new InstanceNest();
		InstanceNest.Inner inner = in.new Inner();
		inner.method2();
	}
}
