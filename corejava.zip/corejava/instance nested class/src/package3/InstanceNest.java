package package3;

public class InstanceNest {
	static String x="static data member of Outer class.";     
	
	String y="instanace data member Outer class.";  

	 class Inner {
		public void method()
		{
			System.out.println(x);
			x="value of static data member has been change.";
			System.out.println(x);
	
			System.out.println(y);
			y="value of instance data member has been change.";
			System.out.println(y);
		}
		
	}
}
