package package3;

import package3.InstanceNest;
import package3.InstanceNest.Inner;

public class Test {
	public static void main(String[] args) {
		InstanceNest in= new InstanceNest();
		InstanceNest.Inner inner = in.new Inner();
		inner.method();
	}
}
