package package5;



public class Test {
	public static void main(String[] args) {
		InstanceNest in= new InstanceNest();
		InstanceNest.Inner1 inner1 = in.new Inner1();
		InstanceNest.Inner1.Inner2 inner2=inner1.new Inner2();
		inner2.method();
		
		//new InstanceNest().new Inner1().new Inner2().method();
	}
}


//public,,abstract,final,strictfp
//<default>,private,protected,static