package package5;

public class InstanceNest {  //nest in inner class
	
	String x="instanace data member Outer class.";  

	 class Inner1 {
		 class Inner2
		 {
			 	    String x="instanace data member innermost class.";  
					public void method()
					{   
						System.out.println(x);
					}
		 }
		
		
	}
}
