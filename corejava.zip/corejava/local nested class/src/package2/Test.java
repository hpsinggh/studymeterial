package package2;

public class Test {
	
	 public static void main(String[] args) {
		 LocalInner x=new LocalInner();
	      x.outerMethod();
	   }
}
