package package2;

public class LocalInner {
	 void outerMethod() {
	      System.out.println("inside outerMethod");
	      class Inner {
	         void innerMethod(int a,int b) {
	        	System.out.println("total is : "+ (a+b));
	         }
	      }
	      Inner y = new Inner();
	      y.innerMethod(10,20);
	      y.innerMethod(100,200);
	   }
}
