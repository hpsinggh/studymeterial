package package4;

public class Test {
	
	public static void main(String[] args)
	{
		LocalInner.outerMethod();
	}    
}
