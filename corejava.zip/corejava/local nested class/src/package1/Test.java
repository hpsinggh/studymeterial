package package1;

public class Test {
	
	public static void main(String[] args)
	{
	    	LocalInner object=new LocalInner();
	        object.outerMethod2();
	}    
}
